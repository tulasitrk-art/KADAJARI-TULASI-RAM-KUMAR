const https = require('https');
const JSONBIN_HOST = 'api.jsonbin.io';
const JSONBIN_KEY = '$2a$10$bUOFVWCKHp1QW1b3bvnXuOTW4VCAtaD8N8CJyHFE6IELrBMtGSc8C';

function httpsReq(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch (e) { resolve({ status: res.statusCode, body: d }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

exports.handler = async (event) => {
  const hdrs = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: hdrs, body: '' };

  if (event.httpMethod === 'POST') {
    try {
      const { urls } = JSON.parse(event.body);
      if (!Array.isArray(urls) || !urls.length) throw new Error('No URLs provided');
      const payload = JSON.stringify({ urls });
      const res = await httpsReq({
        hostname: JSONBIN_HOST, path: '/v3/b', method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': JSONBIN_KEY,
          'X-Bin-Private': 'false',
          'X-Bin-Name': 'trk-gallery',
          'Content-Length': Buffer.byteLength(payload)
        }
      }, payload);
      if (res.status !== 200) throw new Error('Storage error: ' + res.status);
      return { statusCode: 200, headers: hdrs, body: JSON.stringify({ id: res.body.metadata.id }) };
    } catch (e) {
      return { statusCode: 500, headers: hdrs, body: JSON.stringify({ error: e.message }) };
    }
  }

  if (event.httpMethod === 'GET') {
    try {
      const id = (event.queryStringParameters || {}).id;
      if (!id) throw new Error('Missing id');
      const res = await httpsReq({
        hostname: JSONBIN_HOST, path: '/v3/b/' + id + '/latest', method: 'GET',
        headers: { 'X-Master-Key': JSONBIN_KEY }
      });
      if (res.status !== 200) return { statusCode: 404, headers: hdrs, body: JSON.stringify({ error: 'Gallery not found' }) };
      return { statusCode: 200, headers: hdrs, body: JSON.stringify({ urls: res.body.record.urls }) };
    } catch (e) {
      return { statusCode: 500, headers: hdrs, body: JSON.stringify({ error: e.message }) };
    }
  }

  return { statusCode: 405, headers: hdrs, body: JSON.stringify({ error: 'Method not allowed' }) };
};
