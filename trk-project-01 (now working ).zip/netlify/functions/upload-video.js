const https = require('https');
const http = require('http');

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const body = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf8');
    
    // Upload to transfer.sh via server-side (no CORS issues)
    const url = await new Promise((resolve, reject) => {
      const filename = event.headers['x-filename'] || 'video.mp4';
      const options = {
        hostname: 'transfer.sh',
        path: '/' + encodeURIComponent(filename),
        method: 'PUT',
        headers: {
          'Content-Length': body.length,
          'Content-Type': event.headers['content-type'] || 'video/mp4',
          'Max-Days': '365',
        }
      };
      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200 && data.startsWith('http')) resolve(data.trim());
          else reject(new Error('transfer.sh failed: ' + res.statusCode));
        });
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });

    return {
      statusCode: 200,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: e.message })
    };
  }
};
